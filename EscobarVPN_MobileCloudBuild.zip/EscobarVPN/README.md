# Escobar SSH & V2Ray VPN — Android starter

This is a buildable Android UI starter and cloud-build workflow, not a functional VPN. The SSH and V2Ray tunnel engines, packet forwarding, secure profile storage, and working connection logic have NOT been integrated.

## Build APK on GitHub Actions (phone-friendly)
1. Create a GitHub account and a new repository.
2. Upload all project files (including `.github/workflows/build-apk.yml`) to the repository.
3. Open repository → Actions → **Build Escobar VPN APK** → Run workflow.
4. After the workflow completes, open its run page and download the `EscobarVPN-debug-apk` artifact.
5. Extract the ZIP artifact and install the APK on Android.

The APK is a demo interface only; pressing its button will not connect to an SSH or V2Ray server.
