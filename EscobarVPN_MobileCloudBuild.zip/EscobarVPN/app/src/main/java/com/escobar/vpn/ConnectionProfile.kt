package com.escobar.vpn

import android.net.Uri
import android.util.Base64
import org.json.JSONObject

/** Parsed connection metadata. Secrets are deliberately not persisted by this starter. */
data class ConnectionProfile(
    val name: String,
    val protocol: String,
    val host: String,
    val port: Int,
    val userId: String = "",
    val network: String = "tcp",
    val security: String = "none",
    val tlsServerName: String = "",
    val path: String = "",
    val rawUri: String = ""
)

object ProfileParser {
    fun parse(input: String): ConnectionProfile {
        val value = input.trim()
        require(value.isNotEmpty()) { "Paste a V2Ray share link first." }
        return when {
            value.startsWith("vmess://", true) -> parseVmess(value)
            value.startsWith("vless://", true) -> parseVless(value)
            value.startsWith("trojan://", true) -> parseTrojan(value)
            else -> throw IllegalArgumentException("Supported links: vmess://, vless://, trojan://")
        }
    }

    private fun parseVmess(value: String): ConnectionProfile {
        val encoded = value.substringAfter("vmess://")
        val bytes = try { Base64.decode(encoded, Base64.DEFAULT) } catch (_: Exception) {
            Base64.decode(encoded, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        }
        val json = JSONObject(String(bytes, Charsets.UTF_8))
        val host = json.optString("add").trim()
        val port = json.optString("port").toIntOrNull() ?: json.optInt("port")
        require(host.isNotBlank() && port in 1..65535) { "VMess link is missing a valid server or port." }
        return ConnectionProfile(
            name = json.optString("ps").ifBlank { "VMess profile" }, protocol = "VMess",
            host = host, port = port, userId = json.optString("id"),
            network = json.optString("net").ifBlank { "tcp" },
            security = json.optString("tls").ifBlank { "none" },
            tlsServerName = json.optString("sni"), path = json.optString("path"), rawUri = value
        )
    }

    private fun parseVless(value: String): ConnectionProfile {
        val uri = Uri.parse(value)
        val port = uri.port.takeIf { it > 0 } ?: 443
        require(!uri.host.isNullOrBlank() && port in 1..65535) { "VLESS link is missing a valid server or port." }
        val q = uri.queryParameterNames
        return ConnectionProfile(
            name = uri.fragment?.let { Uri.decode(it) }?.ifBlank { null } ?: "VLESS profile",
            protocol = "VLESS", host = uri.host!!, port = port,
            userId = uri.userInfo.orEmpty(),
            network = if ("type" in q) uri.getQueryParameter("type").orEmpty() else "tcp",
            security = uri.getQueryParameter("security") ?: "none",
            tlsServerName = uri.getQueryParameter("sni") ?: uri.getQueryParameter("serverName").orEmpty(),
            path = uri.getQueryParameter("path").orEmpty(), rawUri = value
        )
    }

    private fun parseTrojan(value: String): ConnectionProfile {
        val uri = Uri.parse(value)
        val port = uri.port.takeIf { it > 0 } ?: 443
        require(!uri.host.isNullOrBlank() && port in 1..65535) { "Trojan link is missing a valid server or port." }
        return ConnectionProfile(
            name = uri.fragment?.let { Uri.decode(it) }?.ifBlank { null } ?: "Trojan profile",
            protocol = "Trojan", host = uri.host!!, port = port,
            userId = uri.userInfo.orEmpty(), network = uri.getQueryParameter("type") ?: "tcp",
            security = uri.getQueryParameter("security") ?: "tls",
            tlsServerName = uri.getQueryParameter("sni").orEmpty(),
            path = uri.getQueryParameter("path").orEmpty(), rawUri = value
        )
    }
}
