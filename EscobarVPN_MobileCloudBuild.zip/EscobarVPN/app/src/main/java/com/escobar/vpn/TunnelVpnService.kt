package com.escobar.vpn

import android.net.VpnService
import android.content.Intent

// Placeholder service only. No tunnel or packet forwarding is implemented yet.
class TunnelVpnService : VpnService() {
  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    stopSelf()
    return START_NOT_STICKY
  }
}
