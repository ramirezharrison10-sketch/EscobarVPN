package com.escobar.vpn

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.VpnService
import android.widget.*
import android.view.ViewGroup

class MainActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val layout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,32,32,32) }
    layout.addView(TextView(this).apply { text="ESCOBAR SSH & V2RAY VPN"; textSize=24f })
    layout.addView(TextView(this).apply { text="Starter interface — tunnel engines not yet connected" })
    val modes = Spinner(this)
    modes.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("SSH Tunnel", "V2Ray / VMess / VLESS"))
    layout.addView(modes)
    val host = field("Server hostname or IP", layout)
    val port = field("Port", layout)
    val user = field("SSH username (SSH mode)", layout)
    val pass = field("SSH password (SSH mode)", layout)
    val config = field("V2Ray URI (VMess/VLESS)", layout)
    val status = TextView(this).apply { text="Status: Disconnected" }
    layout.addView(status)
    val button = Button(this).apply { text="Start VPN (demo only)" }
    button.setOnClickListener { status.text="Status: UI demo only — no tunnel engine installed" }
    layout.addView(button)
    setContentView(ScrollView(this).apply { addView(layout) })
  }
  private fun field(hintText:String, parent:LinearLayout):EditText { val e=EditText(this).apply { hint=hintText }; parent.addView(e); return e }
}
