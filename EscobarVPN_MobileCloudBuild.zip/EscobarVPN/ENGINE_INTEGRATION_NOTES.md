# Engine integration notes

## Suggested architecture

- `MainActivity`: configuration and import UI only.
- `ProfileParser`: parse supported share-link formats; preserve original link only in memory until secure storage is implemented.
- `TunnelVpnService`: foreground Android VPN lifecycle, TUN descriptor ownership, notification, start/stop commands.
- `V2RayEngine` adapter: start/stop/status around upstream Xray/libv2ray Android binding.
- `SshEngine` adapter: SSH authentication and local proxy endpoint.
- `Tun2SocksEngine` adapter: route packets read from the Android TUN descriptor to the SSH local proxy.

## Non-negotiable connection sequence

1. Validate a profile and obtain Android VPN consent with `VpnService.prepare()`.
2. Start a foreground service with a persistent notification.
3. Establish and verify the remote engine first (SSH host-key check or Xray config validation).
4. Call `VpnService.Builder.establish()` with explicit routes and DNS.
5. Hand the resulting TUN file descriptor to the engine/tun2socks bridge.
6. Report CONNECTED only after the engine confirms readiness and traffic can pass.
7. On stop/error, close TUN descriptor, stop native engine, disconnect SSH, remove notification, and publish accurate state.

Never report connected merely because VPN permission was granted.
